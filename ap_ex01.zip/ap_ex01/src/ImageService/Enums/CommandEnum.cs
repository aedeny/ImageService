﻿namespace ImageService.Enums
{
    public enum CommandEnum
    {
        NewFileCommand,
        CloseCommand
    }
}