﻿namespace ImageService.Logger.Model
{
    public enum MessageTypeEnum
    {
        Info,
        Warning,
        Failure
    }
}