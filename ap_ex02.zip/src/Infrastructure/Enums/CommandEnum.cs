﻿namespace Infrastructure.Enums
{
    public enum CommandEnum
    {
        NewFileCommand,
        CloseDirectoryHandlerCommand,
        ConfigCommand,
        NewLogCommand,
        LogHistoryCommand
    }
}