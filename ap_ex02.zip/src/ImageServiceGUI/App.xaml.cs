﻿using System.Windows;

namespace ImageServiceGUI
{
    /// <summary>
    ///     Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application { }
}