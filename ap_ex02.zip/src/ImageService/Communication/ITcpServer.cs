﻿namespace ImageService.Communication
{
    public interface ITcpServer
    {
        void Stop();
        void Start();
    }
}